package com.example.voicegesture

import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.example.voicegesture.control.FloatingButtonService
import com.example.voicegesture.control.MyAccessibilityService

class MainActivity : AppCompatActivity() {

    private val REQ_MIC_CAM = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<Button>(R.id.btnOverlayPermission).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
            }
        }

        findViewById<Button>(R.id.btnAccessibilityPermission).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        findViewById<Button>(R.id.btnMicCameraPermission).setOnClickListener {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(android.Manifest.permission.RECORD_AUDIO, android.Manifest.permission.CAMERA),
                REQ_MIC_CAM
            )
        }

        findViewById<Button>(R.id.btnStart).setOnClickListener {
            if (!allPermissionsGranted()) {
                updateStatus("Please grant all three permissions above first.")
                return@setOnClickListener
            }
            val serviceIntent = Intent(this, FloatingButtonService::class.java)
            ContextCompat.startForegroundService(this, serviceIntent)
            updateStatus("Floating button started. You can leave this screen — look for the small circle button on your screen.")
        }
    }

    override fun onResume() {
        super.onResume()
        updateStatus(permissionStatusSummary())
    }

    private fun allPermissionsGranted(): Boolean {
        val overlayOk = Settings.canDrawOverlays(this)
        val accessibilityOk = isAccessibilityServiceEnabled()
        val micOk = ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val camOk = ContextCompat.checkSelfPermission(this, android.Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        return overlayOk && accessibilityOk && micOk && camOk
    }

    private fun permissionStatusSummary(): String {
        val overlayOk = Settings.canDrawOverlays(this)
        val accessibilityOk = isAccessibilityServiceEnabled()
        val micOk = ContextCompat.checkSelfPermission(this, android.Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val camOk = ContextCompat.checkSelfPermission(this, android.Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        return "Overlay: ${if (overlayOk) "OK" else "not granted"} | " +
                "Accessibility: ${if (accessibilityOk) "OK" else "not enabled"} | " +
                "Mic/Camera: ${if (micOk && camOk) "OK" else "not granted"}"
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        val expectedComponentName = "$packageName/${MyAccessibilityService::class.java.canonicalName}"
        val enabledServicesSetting = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        val splitter = TextUtils.SimpleStringSplitter(':')
        splitter.setString(enabledServicesSetting)
        while (splitter.hasNext()) {
            if (splitter.next().equals(expectedComponentName, ignoreCase = true)) return true
        }
        return false
    }

    private fun updateStatus(text: String) {
        findViewById<TextView>(R.id.statusText).text = text
    }
}
