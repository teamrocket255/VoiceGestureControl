package com.example.voicegesture.control

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * This service is what actually DOES things in other apps: open an app,
 * go back/home, find the currently focused text field and type into it,
 * or find a button by its visible text/description and tap it.
 *
 * The user has to turn this on once, manually, in
 * Settings > Accessibility > Voice Gesture Control.
 */
class MyAccessibilityService : AccessibilityService() {

    companion object {
        // A static reference so VoiceCommandManager / GestureController can
        // call into this service without binding. Simple approach for a
        // single-user personal-automation app.
        var instance: MyAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Not used for command execution — commands are triggered directly
        // from VoiceCommandManager / GestureController calling the methods
        // below. Left here in case you want to react to screen changes.
    }

    override fun onInterrupt() {}

    // ---------- Actions callable from voice/gesture commands ----------

    fun goBack() {
        performGlobalAction(GLOBAL_ACTION_BACK)
    }

    fun goHome() {
        performGlobalAction(GLOBAL_ACTION_HOME)
    }

    fun openRecents() {
        performGlobalAction(GLOBAL_ACTION_RECENTS)
    }

    fun openNotifications() {
        performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
    }

    /** Launch an app by its package name, e.g. "com.instagram.android" */
    fun openApp(packageName: String) {
        val launchIntent = applicationContext.packageManager.getLaunchIntentForPackage(packageName)
        if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            applicationContext.startActivity(launchIntent)
        }
    }

    /** Types text into whatever text field is currently focused on screen. */
    fun typeIntoFocusedField(text: String): Boolean {
        val node = findFocusedEditableNode(rootInActiveWindow) ?: return false
        val arguments = Bundle()
        arguments.putCharSequence(
            AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text
        )
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments)
    }

    /** Finds a clickable node whose text or content-description contains the given label, and taps it. */
    fun clickNodeByLabel(label: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val node = findNodeByLabel(root, label.lowercase())
        if (node != null) {
            var target: AccessibilityNodeInfo? = node
            // Walk up to the nearest clickable ancestor
            while (target != null && !target.isClickable) {
                target = target.parent
            }
            return target?.performAction(AccessibilityNodeInfo.ACTION_CLICK) ?: false
        }
        return false
    }

    /** Simulates a tap at specific screen coordinates (used for basic gesture-mapped actions). */
    fun tapAt(x: Float, y: Float) {
        val path = Path()
        path.moveTo(x, y)
        val gestureBuilder = GestureDescription.Builder()
        gestureBuilder.addStroke(GestureDescription.StrokeDescription(path, 0, 50))
        dispatchGesture(gestureBuilder.build(), null, null)
    }

    /** Simulates a swipe, e.g. for a "swipe left/right" hand gesture. */
    fun swipe(startX: Float, startY: Float, endX: Float, endY: Float, durationMs: Long = 300) {
        val path = Path()
        path.moveTo(startX, startY)
        path.lineTo(endX, endY)
        val gestureBuilder = GestureDescription.Builder()
        gestureBuilder.addStroke(GestureDescription.StrokeDescription(path, 0, durationMs))
        dispatchGesture(gestureBuilder.build(), null, null)
    }

    private fun findFocusedEditableNode(root: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        if (root == null) return null
        if (root.isFocused && root.isEditable) return root
        for (i in 0 until root.childCount) {
            val found = findFocusedEditableNode(root.getChild(i))
            if (found != null) return found
        }
        return null
    }

    private fun findNodeByLabel(root: AccessibilityNodeInfo, label: String): AccessibilityNodeInfo? {
        val text = root.text?.toString()?.lowercase()
        val desc = root.contentDescription?.toString()?.lowercase()
        if ((text != null && text.contains(label)) || (desc != null && desc.contains(label))) {
            return root
        }
        for (i in 0 until root.childCount) {
            val child = root.getChild(i) ?: continue
            val found = findNodeByLabel(child, label)
            if (found != null) return found
        }
        return null
    }
}
