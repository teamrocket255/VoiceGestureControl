package com.example.voicegesture.control

/**
 * Turns a recognized voice phrase into an action. Extend the `appPackages`
 * map and the `when` branches below to add more commands — this is meant
 * to be edited to fit exactly what you want to say.
 */
object CommandParser {

    // Add any app you want to open by voice here: spoken name -> package name
    private val appPackages = mapOf(
        "instagram" to "com.instagram.android",
        "whatsapp" to "com.whatsapp",
        "camera" to "com.android.camera",
        "messages" to "com.google.android.apps.messaging",
        "youtube" to "com.google.android.youtube",
        "gmail" to "com.google.android.gm",
        "settings" to "com.android.settings"
    )

    fun handle(rawText: String) {
        val service = MyAccessibilityService.instance ?: return
        val text = rawText.trim().lowercase()

        when {
            // "open instagram", "open whatsapp", etc.
            text.startsWith("open ") -> {
                val appName = text.removePrefix("open ").trim()
                val pkg = appPackages[appName]
                if (pkg != null) service.openApp(pkg)
            }

            // "go back"
            text.contains("go back") || text == "back" -> service.goBack()

            // "go home" / "home screen"
            text.contains("go home") || text.contains("home screen") -> service.goHome()

            // "recent apps" / "show recents"
            text.contains("recent apps") || text.contains("recents") -> service.openRecents()

            // "notifications"
            text.contains("show notifications") || text.contains("open notifications") -> service.openNotifications()

            // "tap send" / "click send" / "press send" -> finds a button labeled "send" and taps it
            text.startsWith("tap ") || text.startsWith("click ") || text.startsWith("press ") -> {
                val label = text.substringAfter(" ").trim()
                service.clickNodeByLabel(label)
            }

            // "type hey what's up" -> types into whatever field is currently focused
            text.startsWith("type ") -> {
                val message = rawText.trim().substring(5) // preserve original casing after "type "
                service.typeIntoFocusedField(message)
            }

            // "type hey what's up and send" / "type hey what's up send"
            text.startsWith("send message ") -> {
                val message = rawText.trim().substring("send message ".length)
                service.typeIntoFocusedField(message)
                service.clickNodeByLabel("send")
            }

            // "message <name> on instagram <text>"  (opens Instagram; you finish picking the chat,
            // then say "send message <text>" once the chat is open — see note above about why
            // full auto-selection of a contact isn't possible)
            text.startsWith("message ") && text.contains(" on ") -> {
                val appPart = text.substringAfter(" on ").trim().split(" ").first()
                val pkg = appPackages[appPart]
                if (pkg != null) service.openApp(pkg)
            }

            else -> {
                // Unknown command — no-op. Log it if you want to see what
                // phrases you're actually saying, to add more mappings.
            }
        }
    }
}
