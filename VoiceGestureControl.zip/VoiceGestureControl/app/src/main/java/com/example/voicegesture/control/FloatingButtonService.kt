package com.example.voicegesture.control

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.lifecycle.LifecycleService
import com.example.voicegesture.MainActivity
import com.example.voicegesture.R

/**
 * Draws the small floating circle button that stays on top of every app.
 * Tap it once to expand two smaller buttons: 🎤 (voice on/off) and
 * ✋ (hand gesture on/off). Tap the main circle again to collapse them.
 * Drag the main circle to move it anywhere on screen.
 */
class FloatingButtonService : LifecycleService() {

    private lateinit var windowManager: WindowManager
    private lateinit var floatingView: View
    private lateinit var params: WindowManager.LayoutParams

    private var voiceEnabled = false
    private var gestureEnabled = false
    private var expanded = false

    private lateinit var voiceManager: VoiceCommandManager
    private var gestureController: GestureController? = null

    override fun onCreate() {
        super.onCreate()
        startForegroundWithNotification()

        voiceManager = VoiceCommandManager(this)

        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        floatingView = LayoutInflater.from(this).inflate(R.layout.floating_button, null)

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            WindowManager.LayoutParams.TYPE_PHONE

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = 0
        params.y = 300

        windowManager.addView(floatingView, params)
        setupTouchAndClicks()
    }

    private fun setupTouchAndClicks() {
        val mainToggle = floatingView.findViewById<TextView>(R.id.mainToggle)
        val subRow = floatingView.findViewById<View>(R.id.subRow)
        val voiceToggle = floatingView.findViewById<TextView>(R.id.voiceToggle)
        val gestureToggle = floatingView.findViewById<TextView>(R.id.gestureToggle)

        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var isDragging = false

        mainToggle.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    isDragging = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - initialTouchX)
                    val dy = (event.rawY - initialTouchY)
                    if (Math.abs(dx) > 10 || Math.abs(dy) > 10) isDragging = true
                    params.x = initialX + dx.toInt()
                    params.y = initialY + dy.toInt()
                    windowManager.updateViewLayout(floatingView, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!isDragging) {
                        // Treat as a tap: expand/collapse the sub-buttons
                        expanded = !expanded
                        subRow.visibility = if (expanded) View.VISIBLE else View.GONE
                    }
                    true
                }
                else -> false
            }
        }

        voiceToggle.setOnClickListener {
            voiceEnabled = !voiceEnabled
            voiceToggle.alpha = if (voiceEnabled) 1.0f else 0.5f
            if (voiceEnabled) voiceManager.start() else voiceManager.stop()
        }

        gestureToggle.setOnClickListener {
            gestureEnabled = !gestureEnabled
            gestureToggle.alpha = if (gestureEnabled) 1.0f else 0.5f
            if (gestureEnabled) {
                gestureController = GestureController(
                    context = this,
                    lifecycleOwner = this,
                    onOpenPalm = { CommandParser.handle("go back") },
                    onFist = { CommandParser.handle("go home") }
                )
                gestureController?.start()
            } else {
                gestureController?.stop()
                gestureController = null
            }
        }
    }

    private fun startForegroundWithNotification() {
        val channelId = "voice_gesture_control_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId, "Voice Gesture Control", NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }

        val openAppIntent = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("Voice Gesture Control is running")
            .setContentText("Tap the floating button to toggle voice / gesture")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(openAppIntent)
            .setOngoing(true)
            .build()

        startForeground(1, notification)
    }

    override fun onDestroy() {
        super.onDestroy()
        voiceManager.stop()
        gestureController?.stop()
        if (::floatingView.isInitialized) {
            windowManager.removeView(floatingView)
        }
    }

    override fun onBind(intent: Intent): IBinder? {
        super.onBind(intent)
        return null
    }
}
