package com.example.voicegesture.control

import android.content.Context
import android.util.Log
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.lifecycle.LifecycleOwner
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarker
import com.google.mediapipe.tasks.vision.handlandmarker.HandLandmarkerResult
import com.google.mediapipe.framework.image.BitmapImageBuilder
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import kotlin.math.abs

/**
 * Detects a small set of simple hand gestures from the front camera and
 * turns them into actions via CommandParser / MyAccessibilityService.
 *
 * SETUP REQUIRED (one-time, can't be done from here):
 * 1. Download "hand_landmarker.task" from Google's MediaPipe model page:
 *    https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/latest/hand_landmarker.task
 * 2. Put the file in: app/src/main/assets/hand_landmarker.task
 *
 * Gestures recognized here (edit `interpretGesture` to add more):
 * - Open palm held still  -> toggles voice listening on/off
 * - Closed fist           -> goes back (like a "cancel")
 * - Swipe hand left/right -> next / previous (mapped to a swipe gesture on screen)
 */
class GestureController(
    private val context: Context,
    private val lifecycleOwner: LifecycleOwner,
    private val onOpenPalm: () -> Unit,
    private val onFist: () -> Unit
) {
    private var handLandmarker: HandLandmarker? = null
    private val cameraExecutor: ExecutorService = Executors.newSingleThreadExecutor()
    private var lastGesture: String? = null
    private var lastGestureTime = 0L

    fun start() {
        setupHandLandmarker()
        startCamera()
    }

    fun stop() {
        cameraExecutor.shutdown()
        handLandmarker?.close()
        handLandmarker = null
    }

    private fun setupHandLandmarker() {
        try {
            val baseOptions = BaseOptions.builder()
                .setModelAssetPath("hand_landmarker.task")
                .build()
            val options = HandLandmarker.HandLandmarkerOptions.builder()
                .setBaseOptions(baseOptions)
                .setRunningMode(RunningMode.LIVE_STREAM)
                .setNumHands(1)
                .setResultListener(this::onHandResult)
                .setErrorListener { e -> Log.e("GestureController", "MediaPipe error: ${e.message}") }
                .build()
            handLandmarker = HandLandmarker.createFromOptions(context, options)
        } catch (e: Exception) {
            Log.e("GestureController", "Failed to load hand_landmarker.task — did you add it to assets/? ${e.message}")
        }
    }

    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()

            val imageAnalyzer = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
                .also {
                    it.setAnalyzer(cameraExecutor) { imageProxy -> analyzeFrame(imageProxy) }
                }

            val cameraSelector = CameraSelector.DEFAULT_FRONT_CAMERA

            try {
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(lifecycleOwner, cameraSelector, imageAnalyzer)
            } catch (e: Exception) {
                Log.e("GestureController", "Camera bind failed: ${e.message}")
            }
        }, cameraExecutor)
    }

    private fun analyzeFrame(imageProxy: ImageProxy) {
        try {
            val bitmap = imageProxy.toBitmap()
            val mpImage = BitmapImageBuilder(bitmap).build()
            handLandmarker?.detectAsync(mpImage, imageProxy.imageInfo.timestamp)
        } catch (e: Exception) {
            Log.e("GestureController", "Frame analysis failed: ${e.message}")
        } finally {
            imageProxy.close()
        }
    }

    private fun onHandResult(result: HandLandmarkerResult, input: com.google.mediapipe.framework.image.MPImage) {
        if (result.landmarks().isEmpty()) return
        val landmarks = result.landmarks()[0]

        // Very simple heuristic: compare fingertip y-position to knuckle
        // y-position for each finger to guess "open palm" vs "fist".
        // Landmark indices follow MediaPipe's 21-point hand model.
        val tips = listOf(8, 12, 16, 20) // index, middle, ring, pinky tips
        val pips = listOf(6, 10, 14, 18) // corresponding lower joints

        var extendedCount = 0
        for (i in tips.indices) {
            val tip = landmarks[tips[i]]
            val pip = landmarks[pips[i]]
            if (tip.y() < pip.y()) extendedCount++ // finger pointing "up" = extended
        }

        val gesture = when {
            extendedCount >= 3 -> "open_palm"
            extendedCount == 0 -> "fist"
            else -> null
        }

        val now = System.currentTimeMillis()
        // Debounce: require the same gesture to be stable-ish and not
        // re-trigger more than once per second
        if (gesture != null && (gesture != lastGesture || now - lastGestureTime > 1000)) {
            lastGesture = gesture
            lastGestureTime = now
            when (gesture) {
                "open_palm" -> onOpenPalm()
                "fist" -> onFist()
            }
        }
    }
}
