# Voice Gesture Control

A personal Android automation app: a small floating button that toggles
always-on voice commands and hand-gesture control, and can open apps,
navigate, and type/tap on your behalf using Android's Accessibility API.

## What you need
- Android Studio (free, from developer.android.com)
- An Android phone (minSdk 26 = Android 8.0+)

## How to build it
1. Open Android Studio → "Open" → select the `VoiceGestureControl` folder.
2. Let Gradle sync (it will download the libraries listed in `app/build.gradle`).
3. **Download the hand gesture model** (one file, ~10MB), required for gesture
   detection to work:
   - Go to: https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/latest/hand_landmarker.task
   - Create a folder `app/src/main/assets/` in the project
   - Put the downloaded file there as `app/src/main/assets/hand_landmarker.task`
   - (If you skip this, everything still works except hand gestures.)
4. Plug in your phone (with USB debugging on) or use an emulator, and click Run.

## How to use it on your phone
1. Open the app once. Tap the three permission buttons in order:
   - "Display over other apps" → toggle it ON for this app
   - "Enable Accessibility Service" → find "Voice Gesture Control" in the list → turn it ON
   - "Allow Microphone + Camera" → tap Allow on both prompts
2. Tap "Start Floating Control Button". A small blue circle appears — it stays
   on top of every app you open.
3. Tap the circle once → two small buttons pop out: 🎤 and ✋. Tap either to
   turn voice or gesture control on/off. Tap the main circle again to hide them.
4. Drag the circle anywhere on screen; it stays put between apps.

## Voice commands that work out of the box
- "open instagram" / "open whatsapp" / "open youtube" / "open gmail" / "open settings" / "open messages" / "open camera"
- "go back"
- "go home"
- "recent apps"
- "type <whatever you say>" → types into whichever text box is currently focused/tapped on screen
- "send message <text>" → types the text into the focused field AND taps a button labeled "send"
- "tap <label>" / "click <label>" / "press <label>" → finds any on-screen button whose text/description contains that word and taps it

Add more by editing `CommandParser.kt` — it's a simple `when` block, and
`appPackages` at the top is where you add more apps by name.

## Hand gestures that work out of the box
- ✋ Open palm → triggers "go back"
- ✊ Closed fist → triggers "go home"

Edit `GestureController.kt`'s `interpretGesture`-equivalent logic (see the
`when (gesture)` block) to map more gestures to more actions — e.g. a swipe
gesture calling `service.swipe(...)`.

## Important limitation — please read
**No app, including this one, can make Instagram (or WhatsApp, etc.) send a
message to an arbitrary contact you just named out loud, fully hands-off.**
Instagram deliberately blocks other apps from typing into its search bar or
auto-selecting a chat — this is a security measure, not something specific
to this app, and it applies to every automation tool. What this app *can*
do:
- Open Instagram for you by voice/gesture
- Once you're on any chat screen (yours, tapped manually or by voice-driven
  navigation), type your dictated message into the box and tap Send for you

So the real workflow is: "open instagram" → tap into the chat you want →
"send message hey, how's it going" — the last step is fully hands-free.

## Files
```
app/src/main/java/com/example/voicegesture/
  MainActivity.kt                    – permission setup screen
  control/FloatingButtonService.kt   – the floating draggable button + toggles
  control/MyAccessibilityService.kt  – performs actions in other apps
  control/VoiceCommandManager.kt     – always-on speech recognition
  control/CommandParser.kt           – maps spoken phrases to actions (EDIT THIS to add commands)
  control/GestureController.kt       – camera-based hand gesture detection
```
